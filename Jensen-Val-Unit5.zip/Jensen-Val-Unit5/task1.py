# Task 1 - Dr. Moody
# Creator - Val Jensen
# Unit 5 Assignment
# Course - CS-1400-LO1 XL

import turtle


class Face:
    def __init__(self):
        self.__smile = True
        self.__happy = True
        self.__darkEyes = True

    def draw_face(self):
        turtle.clear()
        self.__drawHead()
        self.__drawEyes()
        self.__drawMouth()

    def isSmile(self):
        return self.__smile

    def isHappy(self):
        return self.__happy

    def isDarkEyes(self):
        return self.__darkEyes

    def changeMouth(self):
        self.__smile = False if self.isSmile() else True
        self.draw_face()

    def changeEmotion(self):
        self.__happy = False if self.isHappy() else True
        self.draw_face()

    def changeEyes(self):
        self.__darkEyes = False if self.isDarkEyes() else True
        self.draw_face()

    def __drawHead(self):
        turtle.speed(0)
        turtle.showturtle()
        turtle.penup()
        turtle.goto(0, -100)
        turtle.pensize(1)
        turtle.setheading(0)
        turtle.begin_fill()
        if self.isHappy():
            turtle.color("black", "yellow")
        else:
            turtle.color("black", "red")
        turtle.pendown()
        turtle.circle(100)
        turtle.end_fill()
        turtle.penup()

    def __drawEyes(self):
        if self.isDarkEyes():
            turtle.color("black")
        else:
            turtle.color("black", "blue")
        turtle.goto(-30, 25)
        turtle.begin_fill()
        turtle.pendown()
        turtle.circle(10)
        turtle.end_fill()
        turtle.penup()
        turtle.goto(30, 25)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(10)
        turtle.end_fill()
        turtle.penup()

    def __drawMouth(self):
        turtle.color("black")
        if self.isSmile():
            turtle.goto(-70, -30)
            turtle.setheading(-45)
        else:
            turtle.goto(70, -50)
            turtle.setheading(135)
        turtle.pendown()
        turtle.pensize(6)
        turtle.circle(100, 90)
        turtle.hideturtle()

def main():
    face = Face()
    face.draw_face()

    done = False

    while not done:
        print("Change My Face")
        mouth = "frown" if face.isSmile() else "smile"
        emotion = "angry" if face.isSmile() else "happy"
        eyes = "blue" if face.isDarkEyes() else "black"
        print("1) Make me", mouth)
        print("2) Make me", emotion)
        print("3) Make my eyes", eyes)
        print("0) Quit")

        menu = eval(input("Enter a selection: "))

        if menu == 1:
            face.changeMouth()
        elif menu == 2:
            face.changeEmotion()
        elif menu == 3:
            face.changeEyes()
        else:
            break

    print("Thanks for Playing")

    turtle.hideturtle()
    turtle.done()


main()
