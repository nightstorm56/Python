# Task 2 - Blobber
# Creator - Val Jensen
# Unit 5 Assignment
# Course - CS-1400-LO1 XL

from modules.blobber import Blobber
blobber = Blobber()


def main():
    blobber.setName(input("Enter your Blobber's name: "))
    blobber.setColor(input("Enter your Blobber's color: "))
    blobber.setRadii(eval(input("Enter your Blobber's radius: ")))
    blobber.setHeight(eval(input("Enter your Blobber's height: ")))
    blobber.setVolumes()
    blobber.setBioClock()
    blobber.shrinkage()

    mainMenu()
    print("Thanks for taking care of a Blobber")


def mainMenu():

    print("\nMain Menu")
    print("\t(1) Display Name")
    print("\t(2) Change Name")
    print("\t(3) Display Color")
    print("\t(4) Change Color")
    print("\t(5) Feed Blobber")
    print("\t(6) Blobber Speak")
    print("\t(7) Exit")

    menu = eval(input("Make a selection: "))

    if menu == 1:
        print("Your Blobber's name is " + blobber.getName())
        mainMenu()
    elif menu == 2:
        blobber.setName(input("Enter your Blobber's new name: "))
        mainMenu()
    elif menu == 3:
        print("Your Blobber's color is " + blobber.getColor())
        mainMenu()
    elif menu == 4:
        blobber.setColor(input("Enter your Blobber's new color: "))
        mainMenu()
    elif menu == 5:
        blobber.feedBlobber(eval(input("Enter amount you want to feed your Blobber: ")))
        if blobber.vitalsOK():
            mainMenu()
        elif blobber.getCurrrentHappy() < .9:
            print("You waited too long to feed " + blobber.getName() + " " + blobber.getColor(), end="")
            print(" and it turned to dust")
        else:
            print("That was too much. " + blobber.getName() + " " + blobber.getColor() + " turned to dust")
    elif menu == 6:
        blobber.shrinkage()
        print(blobber.blobberSpeak())
        if blobber.vitalsOK():
            mainMenu()


main()