# Task 3 - Wordinator
# Creator - Val Jensen
# Unit 5 Assignment
# Course - CS-1400-LO1 XL

class Wordinator:
    def __init__(self, word):
        self.__word = word

    def getWord(self):
        return self.__word

    def __add__(self, word):
        return self.__word + word.getWord()

    def __mul__(self, value):
        return self.__word.upper() * value

    def __len__(self):
        return len(self.__word)

    def __lt__(self, word):
        if self.__word < word:
            return self.__word

    def __gt__(self, word):
        if self.__word > word:
            return self.__word

    def __str__(self):
        return self.__word

    def __truediv__(self, word):
        newWord = ""
        i = 0
        count = 0
        myBool = True

        while len(newWord) <= (len(self.__word) + len(word))-1:

            if myBool:

                if i <= len(self.__word)-1:

                    if i == 0:
                        newWord += self.__word[i].upper()
                    else:
                        newWord += self.__word[i].lower()

                myBool = False
                count += 1
            else:
                if i <= len(word)-1:
                    if i == 0:
                        newWord += word[i].upper()
                    else:
                        newWord += word[i].lower()
                myBool = True
                count += 1
            if count == 2:
                i += 1
                count = 0

        return newWord

    def __getitem__(self, item):
        return self.__word[item]

    def __setitem__(self, item):
        self.__word[item] = str(self.__word[item])

    def __mod__(self, word):
        firstWord = secondWord = ""
        count = 0
        myBool = True

        while count < 2:
            wordCapture = ""

            if myBool:
                wordCapture += self.__word
            else:
                wordCapture += str(word)
            wordMid = int(len(wordCapture)/3)
            wordCapture = wordCapture[wordMid:-wordMid:1]

            if myBool:
                firstWord += wordCapture
                myBool = False
            else:
                secondWord += wordCapture
                myBool = True

            count += 1

        return firstWord, secondWord

    def __sub__(self, word):
        firstWord = secondWord = ""
        count = 0
        myBool = True

        while count < 2:
            wordCapture = newWord = ""

            if myBool:
                wordCapture += self.__word
            else:
                wordCapture += str(word)

            for i in range(0, len(wordCapture)):
                if wordCapture[i].isupper():
                    newWord += wordCapture[i].lower()
                else:
                    newWord += wordCapture[i].upper()

            if myBool:
                firstWord += newWord
                myBool = False
            else:
                secondWord += newWord
                myBool = True

            count += 1

        return firstWord, secondWord


    def backWordSlice(self):
        newWord = ""
        i = 1
        while i <= len(self.__word):
            newWord += self.__word[-i:-i+1]
            i += 1

        return newWord

    def backWordManual(self):
        newWord = ""
        i = 1
        while i <= len(self.__word):
            newWord += self.__word[len(self.__word)-i]
            i += 1

        return newWord
