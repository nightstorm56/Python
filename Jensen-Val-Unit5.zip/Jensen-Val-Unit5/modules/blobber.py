# Task 2 - Blobber
# Creator - Val Jensen
# Unit 5 Assignment
# Course - CS-1400-LO1 XL

from time import time
from math import pi


class Blobber:
    def __init__(self, radius=50, height=100, volume=pi):
        self.__radius = radius
        self.__height = height
        self.__volume = volume * ((self.__radius ** 2) * self.__height)
        self.__currentVolume = self.__volume
        self.__currentRadius = self.__radius
        self.__color = ""
        self.__name = ""
        self.__bioClock = self.__bioClock2 = time()

    def setName(self, name):
        self.__name = name

    def getName(self):
        return self.__name

    def setColor(self, color):
        self.__color = color

    def getColor(self):
        return self.__color

    def setRadii(self, radius):
        self.__radius = radius
        self.__currentRadius = radius

    def getRadius(self):
        return self.__radius

    def getCurrentRadius(self):
        return self.__currentRadius

    def setHeight(self, height):
        self.__height = height

    def getHeight(self):
        return self.__height

    def setVolumes(self):
        self.__volume = self.__currentVolume = pi * ((self.__radius ** 2) * self.__height)

    def getVolume(self):
        return self.__volume

    def setCurrentVolume(self):
        self.__currentVolume = pi * ((self.__currentRadius ** 2) * self.__height)

    def getCurrentVolume(self):
        return self.__currentVolume

    def feedBlobber(self, food):
        Blobber.shrinkage(self)
        self.__currentRadius = self.__currentRadius + food

    def getCurrrentHappy(self):
        Blobber.shrinkage(self)
        return self.__currentVolume / self.__volume

    def blobberSpeak(self):
        string = ""
        Blobber.shrinkage(self)
        if Blobber.vitalsOK(self):
            string += "My name is " + Blobber.getName(self) + " " + Blobber.getColor(self) + ". "
            string += "My current happiness is " + str(format(Blobber.getCurrrentHappy(self), "0.2%"))
        else:
            string += "Sorry, " + Blobber.getName(self) + " " + Blobber.getColor(self) + " turned to dust"
        return string

    def vitalsOK(self):
        Blobber.shrinkage(self)
        return False if(Blobber.getCurrrentHappy(self) > 1.1) or (Blobber.getCurrrentHappy(self) < .9) else True

    def setBioClock(self):
        self.__bioClock = time()

    def getBioClock(self):
        return self.__bioClock

    def shrinkage(self):
        timeLoss = time() - self.__bioClock
        self.__bioClock = time()
        self.__currentRadius -= (((self.__radius * .002) * timeLoss) / 2) * 1.11
        Blobber.setCurrentVolume(self)