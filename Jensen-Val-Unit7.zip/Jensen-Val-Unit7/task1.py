# Task 1 - Blackjack
# Creator - Val Jensen
# Unit 7 Assignment
# Course - CS-1400-LO1 XL

from modules.deck import Deck
from time import sleep


def main():
    gameList = [["Players"], ["Funds"], ["Bet"], ["Busted"], ["Hand Total"]]
    numPlayers = eval(input("Welcome to Python Blackjack!\nEnter the number of players (1-5): "))
    done = False

    for i in range(1, numPlayers+1):
        gameList[0].append(str(i))
        gameList[1].append(100)
        gameList[2].append(0)
        gameList[3].append(False)
        gameList[4].append(0)

    while not done:
        print()
        gameRound(gameList)
        roundEnd(gameList)
        done = finishUp(gameList)

    print("Thank you for playing!\nResults:")
    endPlayers = []
    endFunds = []
    for i in range(1, len(gameList[0])):
        endPlayers.append(gameList[0][i])
    for i in range(1, len(gameList[1])):
        endFunds.append(gameList[1][i])
    endPlayers, endFunds = bubbleSort(endPlayers, endFunds)
    for i in range(len(endPlayers)):
        print("Player " + str(endPlayers[i]) + ": " + str(endFunds[i]))

def gameRound(gameList):
    gameDeck = Deck()
    hands = []

    takingBets(gameList)
    for _ in gameList[0]:
        hands.append([])

    for i in range(0, 2):
        for j in range(0, len(gameList[0])):
            if j < len(gameList[0]) - 1 and gameList[1][j+1] > 0:
                print("Dealing Player " + str(j + 1))
                sleep(0.5)
                hands[j].append(gameDeck.draw())
            elif j == len(gameList[0]) - 1:
                print("Dealing Dealer")
                sleep(0.5)
                hands[j].append(gameDeck.draw())
            else:
                continue

    for i in range(0, len(gameList[0]) - 1):
        stand = False
        while not stand:
            if gameList[1][i+1] > 0:
                print("\nDealer Hand: [XXX of XXX, " + str(hands[len(hands) - 1][1]) + "] ", end="")
                print("Revealed total: ", end="")
                if hands[len(hands) - 1][1].getCardValue() > 10:
                    print("10", end="")
                else:
                    print(str(hands[len(hands) - 1][1].getCardValue()), end="")
                if hands[len(hands) - 1][1].getCardValue() == 1:
                    print("/11")
                else:
                    print()
                print("Player " + str(i+1) + ": " + str(hands[i]) + " ", end="")
                gameList[4][i] = getCardValues(hands[i])
                print("Card total is: " + str(gameList[4][i]), end="")
                if gameList[4][i] <= 21:
                    for k in range(len(hands[i])):
                        if hands[i][k].getCardValue() == 1 and (gameList[4][i] + 10) <= 21:
                            print("/" + str(gameList[4][i] + 10), end="")
                            break
                    print()
                else:
                    print()
                    print("Player has BUSTED!")
                    gameList[3][i+1] = True
                    break

                choice = input("Would you like to: [H]it or [S]tand?: ")
                if choice == "H" or choice == "h":
                    print("Player " + str(i+1) + " hits")
                    hands[i].append(gameDeck.draw())
                else:
                    for k in range(len(hands[i])):
                        if hands[i][k].getCardValue() == 1 and (gameList[4][i] + 10) <= 21:
                            gameList[4][i] += 10
                            break
                    print("Player " + str(i + 1) + " stands")
                    stand = True
            else:
                stand = True
                continue

    sleep(0.25)
    dealerStand = False
    print("\nRevealing The Dealer's hand...", end="")
    sleep(1.0)
    while not dealerStand:
        print("\nThe Dealer's hand: " + str(hands[len(hands) - 1]), end="")
        dealerTotal = getCardValues(hands[len(hands) - 1])
        for i in range(len(hands[len(hands) - 1])):
            if hands[len(hands) - 1][i].getCardValue() == 1 and (dealerTotal + 10) <= 21:
                dealerTotal += 10
                break
        print(" Card total is: " + str(dealerTotal))
        sleep(1.0)
        if dealerTotal >= 17:
            if dealerTotal <= 21:
                print("The Dealer holds")
                dealerStand = True
            else:
                print("The Dealer busts")
                dealerStand = True
        else:
            print("The Dealer takes a card")
            hands[len(hands) - 1].append(gameDeck.draw())
            sleep(1.0)
        gameList[4][len(gameList[4]) - 1] = dealerTotal


def takingBets(gameList):
    for i in range(1, len(gameList[0])):
        if gameList[1][i] > 0:
            print("Player " + str(i) + " - Current balance: " + str(gameList[1][i]))

            print("Enter bet amount (min. ", end="")
            bet = eval(input("5): ")) if gameList[1][i] > 5 else eval(input(str(gameList[1][i]) + "): "))

            if bet < gameList[1][i]+1:
                if gameList[1][i] > 5:
                    if bet < 5:
                        print("Your bet must be at least 5! Bet changed to 5")
                        gameList[2][i] = 5
                    else:
                        gameList[2][i] = bet
                else:
                    if bet > gameList[1][i]:
                        print("Your bet cannot exceed your balance! Bet changed to current balance")
                        gameList[2][i] = gameList[1][i]
                    elif bet < gameList[1][i]:
                        print("Your bet must be at least " + str(gameList[1][i]), end="")
                        print("! Bet changed to " + str(gameList[1][i]))
                        gameList[2][i] = gameList[1][i]
                    else:
                        gameList[2][i] = bet
            else:
                print("Your bet cannot exceed your balance! Bet changed to current balance")
                gameList[2][i] = gameList[1][i]


def getCardValues(hand):
    cardTotal = 0
    for j in range(len(hand)):
        if hand[j].getCardValue() > 10:
            cardTotal += 10
        else:
            cardTotal += hand[j].getCardValue()
    return cardTotal


def roundEnd(gameList):
    print("Calculating Wins/Losses", end="")
    for i in range(5):
        print(".", end="")
        sleep(0.5)
    print()
    if gameList[4][len(gameList[4]) - 1] > 21:
        for i in range(1, len(gameList[0])):
            if gameList[1][i] > 0:
                if not gameList[3][i]:
                    print("Player " + str(gameList[0][i]) + " wins " + str(gameList[2][i]))
                    gameList[1][i] += gameList[2][i]
                else:
                    print("Player " + str(gameList[0][i]) + " loses " + str(gameList[2][i]) + " from busting")
                    gameList[1][i] -= gameList[2][i]
    else:
        dealerTotal = gameList[4][len(gameList[4]) - 1]
        for i in range(1, len(gameList[4])):
            if gameList[1][i] > 0:
                if gameList[4][i-1] > dealerTotal and not gameList[3][i]:
                    print("Player " + str(gameList[0][i]) + " wins " + str(gameList[2][i]))
                    gameList[1][i] += gameList[2][i]
                elif gameList[4][i-1] < dealerTotal and not gameList[3][i]:
                    print("Player " + str(gameList[0][i]) + " loses " + str(gameList[2][i]))
                    gameList[1][i] -= gameList[2][i]
                elif gameList[4][i-1] == dealerTotal and not gameList[3][i]:
                    print("Player " + str(gameList[0][i]) + " tied The Dealer. No win/loss")
                else:
                    print("Player " + str(gameList[0][i]) + " loses " + str(gameList[2][i]) + " from busting")
                    gameList[1][i] -= gameList[2][i]

    print()
    for i in range(1, len(gameList[0])):
        print("Player " + str(gameList[0][i]) + "'s new total: " + str(gameList[1][i]))
    sleep(1.0)


def finishUp(gameList):
    allTotal = 0
    gameContinue = False
    while not gameContinue:
        for i in range(1, len(gameList[1])):
            allTotal += gameList[1][i]
        if allTotal == 0:
            print("\nNo player has an available balance to continue. Game Over. ", end="")
            return True
        else:
            result = input("Would you like to play again? [Y]es or [N]o: ")
            if result == "Y" or result == "y":
                for i in range(1, len(gameList[2])):
                    gameList[2][i] = 0
                    gameList[3][i] = False
                return False
            elif result == "N" or result == "n":
                return True
            else:
                print("You have entered an invalid choice.")


def bubbleSort(players, funds):
    swapped = True
    while swapped:
        swapped = False
        for i in range(len(funds) - 1):
            if funds[i] < funds[i + 1]:
                players[i], players[i + 1] = players[i + 1], players[i]
                funds[i], funds[i + 1] = funds[i + 1], funds[i]
                swapped = True
    return players, funds


main()