# Task 4 - Program to determine elephant sleeping pens and percentages of zookeeper finds
# Creator - Val Jensen
# Unit 3 Assignment
# Course - CS-1400-LO1 XL

# Import needed module
from random import randint

# Create variable for running or ending the program
tryAgain = True

while tryAgain is True:
    # Create variables to track the zookeeper's findings and the elephant's movements
    elephantCount = 0
    twoElephant = 0

    # Begin the nightly checks
    for night in range(1, 100001):
        # Elephant's movements
        elephant1 = randint(1, 6)
        elephant2 = randint(1, 6)
        # Which pen the zookeeper checks
        zookeeperCheck = randint(1, 6)

        # If the pen the zookeeper checks has both elephants, log that he found both elephants
        if zookeeperCheck == elephant1 == elephant2:
            twoElephant += 1
            elephantCount += 1
        # If the pen the zookeeper checks has any elephant in it, log that he found one elephant
        elif zookeeperCheck == elephant1 or zookeeperCheck == elephant2:
            elephantCount += 1
        # Go to the next night
        night += 1

    # Once all 100,000 nights are complete, display the percentages of the zookeeper's findings
    print("Percentage Zookeeper Found Any Elephants: " + str(format(elephantCount / 100000, "0.2%")))
    print("Percentage Zookeeper Found Both Elephants: " + str(format(twoElephant / 100000, "0.2%")))
    # With a 2% margin of error (31-35% for any found elephants and 5.22-5.89% for finding two), display who is right
    if elephantCount < 31333 or elephantCount > 35333 or twoElephant < 5222 or twoElephant > 5888:
        print("The Custodian is correct")
    else:
        print("The Zookeeper is correct")

    # Ask the user if they would like to rerun the simulation
    userInput = input("Run the simulation again? (yes or no): ")
    if userInput.lower() == "yes" or userInput.lower() == "y":
        tryAgain = True
    else:
        tryAgain = False
        print("Ending simulation program.")