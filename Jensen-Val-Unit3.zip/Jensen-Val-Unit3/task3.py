# Task 3 - Program to find all fluky numbers between 1 and 10000. There should be seven total.
# Creator - Val Jensen
# Unit 3 Assignment
# Course - CS-1400-LO1 XL

# Import needed modules
from random import seed
from random import randint
from time import time

# Set initial variables
x = 1
total = 0
innerLoops = 0
outerLoops = 0
msg = ""

# Collect the starting time
startTime = time()

# Begin searching for fluky numbers
while x <= 10000:
    for i in range(1, x):
        # Once we hit seven iterations of the requirement, stop attempting to search for more
        if outerLoops == 7:
            break
        # Check to see if the current iteration divides evenly in to the current cycle
        # If so, it is a factor of a number and should be used to find a fluky number.
        elif (x % i) == 0:
            seed(i)
            total = total + randint(1, x)
            i += 1
            # Count how many times the program does the calculations
            innerLoops += 1
    # After cycling through all possible factors, if they add up to the current iteration, then it is a fluky number
    if total == x:
        msg += "Fluky Number: " + str(x) + "\n"
        outerLoops += 1
        total = 0
    x += 1
    total = 0

# Capture the time the 'while' statement stops running
endTime = time()

# Calculate the total time it took to run
totalTime = endTime - startTime
msg += "Total Time: " + str(format(totalTime, "0.2f")) + " seconds\nTotal Loops: " + str(innerLoops)

# Display all the captured data
print(msg)