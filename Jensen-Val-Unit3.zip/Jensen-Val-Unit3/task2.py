# Task 2 - Program that will perform an analysis on a social situation
# Creator - Val Jensen
# Unit 3 Assignment
# Course - CS-1400-LO1 XL

# Prompt for first person's information
firstName = input("Welcome to the Social Situation Analyzer System\nPerson One\n\tEnter your name: ")
xPos1, yPos1 = eval(input("\tEnter your position (x, y): "))
rad1 = int(input("\tEnter your personal space radius: "))

# Prompt for second person's information
secondName = input("\nPerson Two\n\tEnter your name: ")
xPos2, yPos2 = eval(input("\tEnter your position (x, y): "))
rad2 = int(input("\tEnter your personal space radius: "))

# Calculate the distance of the people from each other
squareDistance = (xPos1 - xPos2) * (xPos1 - xPos2) + (yPos1 - yPos2) * (yPos1 - yPos2)
squareRootDistance = squareDistance ** 0.5

# Calculate the sizes of the personal spaces
radiusSquared = (rad1 + rad2) * (rad1 + rad2)

# Calculation to help determine if one circle is inside of another at all
isInsideFirst = squareRootDistance + rad1
isInsideSecond = squareRootDistance + rad2

# Calculation to help determine if either person is in the other's personal space
personInsideFirst = (squareDistance + rad1) - squareRootDistance
personInsideSecond = (squareDistance + rad2) - squareRootDistance

# Begin display message construction
msg = "\nSocial Situation Analysis Results\n"

# These two lines determine if either circle is completely inside of the other and displays accordingly
if isInsideFirst < rad2:
    msg += "\t" + firstName + "'s personal space is completely inside " + secondName + "'s personal space\n"
elif isInsideSecond < rad1:
    msg += "\t" + secondName + "'s personal space is completely inside " + firstName + "'s personal space\n"
# This line will show if the circles overlap at all
elif squareDistance < radiusSquared:
    msg += "\t" + firstName + " and " + secondName + "'s personal spaces overlap\n"
# This line will show if the circles don't interact at all
else:
    msg += "\t" + firstName + " and " + secondName + "'s personal spaces do not overlap\n"

# This line will display if both people are in each other's personal space
if personInsideSecond > squareDistance and personInsideFirst > squareDistance:
    msg += "\t" + firstName + " and " + secondName + " are in each other's personal space"
# These two lines determine if either person is in the other's space and displays accordingly
elif personInsideFirst > squareDistance:
    msg += "\t" + secondName + " is in " + firstName + "'s personal space"
elif personInsideSecond > squareDistance:
    msg += "\t" + firstName + " is in " + secondName + "'s personal space"
# This line will display if neither person is in the other's space
else:
    msg += "\tNeither " + firstName + " or " + secondName + " are inside the other person's personal space"

# Display the gathered data
print(msg)

# The below code is purely for testing to visually show and prove the output.
# This doesn't draw properly on tiny outputs, but comes close
# Remove commenting from each line below to have a turtle draw the data out

# import turtle

# turtle.penup()
# turtle.goto(xPos1, yPos1 - rad1)
# turtle.pendown()
# turtle.color("blue")
# turtle.circle(rad1)
# turtle.penup()
# turtle.goto(xPos2, yPos2 - rad2)
# turtle.pendown()
# turtle.color("red")
# turtle.circle(rad2)
# turtle.penup()
# turtle.goto(xPos1, yPos1 - rad1)
# turtle.pendown()
# turtle.color("blue")
# turtle.circle(rad1)
# turtle.penup()
# turtle.goto(xPos2, yPos2 - 1)
# turtle.pendown()
# turtle.color("black")
# turtle.write(secondName)
# turtle.begin_fill()
# turtle.circle(2)
# turtle.end_fill()
# turtle.penup()
# turtle.goto(xPos1, yPos1 - 1)
# turtle.pendown()
# turtle.write(firstName)
# turtle.begin_fill()
# turtle.circle(2)
# turtle.end_fill()
# turtle.penup()
# turtle.hideturtle()
# turtle.goto(0, 0)
# turtle.done()