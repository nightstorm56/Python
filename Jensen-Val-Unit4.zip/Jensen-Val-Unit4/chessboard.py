# Task 2 - Build a chessboard based on user input
# Creator - Val Jensen
# Unit 4 Assignment
# Course - CS-1400-LO1 XL

import turtle


# Inner Rectangles module - made to draw individual rectangles
def drawRectangle(width, height):
    turtle.pendown()
    turtle.begin_fill()
    turtle.forward(width / 8)
    turtle.left(90)
    turtle.forward(height / 8)
    turtle.left(90)
    turtle.forward(width / 8)
    turtle.left(90)
    turtle.forward(height / 8)
    turtle.end_fill()
    turtle.penup()
    turtle.left(90)


# Inner Rectangles Drawing module - this loops to draw all the needed rectangles based on the user input
def drawAllRectangles(startX, startY, width, height):
    i = 1
    # Since we know a chessboard has 8 rows, we only need the process to loop eight times
    for i in range(i, 9):
        # This determines if it needs to draw "Black, White, Black, White, etc." or "White, Black, White, Black, etc."
        # Every other row needs to be "White, Black, White, Black, etc."
        if i % 2 == 0:
            turtle.forward(width / 8)
        x = 1
        while x < 5:
            # Call the Inner Rectangles module to draw a rectangle
            drawRectangle(width, height)
            # This is more to help visually with the output - once it hits four, it doesn't need to proceed forward
            # to draw more rectangles
            if x < 4:
                turtle.forward(width / 4)
            x += 1
        # This helps determine which row needs to be drawn next
        if i < 8:
            turtle.goto(startX, (startY + (height / 8) * i))
        i += 1
    # Hide the turtle once the drawing is complete
    turtle.hideturtle()


# Chessboard Drawing module - starts with drawing the outer chessboard, then proceeds to draw the inner rectangles
def drawChessboard(startX, startY, width=250, height=250):
    turtle.speed(0)
    turtle.penup()
    turtle.goto(startX, startY)
    turtle.pendown()
    turtle.color("red")
    turtle.forward(width)
    turtle.left(90)
    turtle.forward(height)
    turtle.left(90)
    turtle.forward(width)
    turtle.left(90)
    turtle.forward(height)
    turtle.left(90)
    turtle.color("black")
    drawAllRectangles(startX, startY, width, height)
    turtle.done()
