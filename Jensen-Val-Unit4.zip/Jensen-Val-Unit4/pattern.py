# Task 3 - Draw rectangular and circular patterns based on user input
# Creator - Val Jensen
# Unit 4 Assignment
# Course - CS-1400-LO1 XL

import turtle
from random import randint


# Set up the turtle environment
def setup():
    # Turtle set to max speed
    turtle.speed(0)
    # Turtle screen size - 1000x800
    turtle.screensize(1000, 800)
    # Make sure the turtle starts in the "up" position so no lines are drawn until needed
    turtle.penup()


# Random Color module
def randomColor():
    # Chooses a random number between 1 and 4, then changes the turtle's color based on that number
    randColor = randint(1, 4)
    if randColor == 1:
        turtle.color("blue")
    elif randColor == 2:
        turtle.color("green")
    elif randColor == 3:
        turtle.color("black")
    else:
        turtle.color("red")


# Rectangle drawing module
def drawRectangle(width, height, rotation):
    # Select a random color every time this function is called
    randomColor()
    turtle.pendown()
    turtle.right(rotation)
    turtle.forward(height)
    turtle.left(90)
    turtle.forward(width)
    turtle.left(90)
    turtle.forward(height)
    turtle.left(90)
    turtle.forward(width)
    turtle.left(90)
    turtle.left(rotation)
    turtle.penup()


# Rectangle Pattern module
def drawRectanglePattern(centerX, centerY, offset, width, height, count, rotation):
    x = 1
    # Collect a variable that help determine where a rectangle needs to be drawn based on a circle
    # We divide the count of how many rectangles by the degrees of the circle
    startPosition = 360 / count
    # Begin the loop for however many rectangles we need
    while x < count+1:
        turtle.goto(centerX, centerY)
        turtle.forward(offset)
        drawRectangle(width, height, rotation)
        turtle.left(startPosition)
        x += 1


# Circle Pattern module
def drawCirclePattern(centerX, centerY, offset, radius, count):
    x = 1
    # Collect a variable that help determine where a circle needs to be drawn based on the degrees of a circle
    # We divide the count of how many circles by the degrees of the circle
    startPosition = 360 / count
    # Begin the loop for however many circles we need
    while x < count + 1:
        # Select a random color every time this function is called
        randomColor()
        turtle.goto(centerX, centerY)
        turtle.forward(offset)
        # We need the turtle to briefly turn 90 degrees so the circles line up properly when being drawn
        turtle.right(90)
        turtle.pendown()
        turtle.circle(radius)
        turtle.penup()
        # This undoes the brief turn
        turtle.left(90)
        turtle.left(startPosition)
        x += 1


# Super Pattern module - set a default of five patterns if the user doesn't choose a quantity
def drawSuperPattern(num=5):
    x = 1
    # Begin the loop for selecting and drawing patterns
    while x < num + 1:
        # This variable helps determine if the pattern will be the circles or rectangles
        random = randint(1, 2)
        # These variable are in place to randomize the position and offset of each pattern
        centerX = randint(-400, 400)
        centerY = randint(-300, 300)
        offset = randint(-100, 100)
        # Based on the 'random' variable, this choose which pattern type is selected
        if random == 1:
            drawRectanglePattern(centerX, centerY, offset, width=randint(10, 400), height=randint(10, 400), count=randint(2, 90), rotation=randint(-89, 89))
        else:
            drawCirclePattern(centerX, centerY, offset, radius=randint(10, 400), count=randint(2, 90))
        x += 1


# Turtle Reset module
def reset():
    turtle.clear()
    turtle.penup()
    turtle.goto(0, 0)
    turtle.setheading(0)


# Turtle Done module - This keeps the turtle screen open for the user after they've selected to end the drawings
def done():
    turtle.hideturtle()
    turtle.done()
