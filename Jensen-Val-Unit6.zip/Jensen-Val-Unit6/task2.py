# Task 2 - Number calculations
# Creator - Val Jensen
# Unit 6 Assignment
# Course - CS-1400-LO1 XL

list = []
done = False
while not done:
    userInput = input("Enter a number, leave blank to end data capture: ")
    if userInput:
        list.append(int(userInput))
    else:
        done = True

print("Number of values entered: " + str(len(list)))

capture = ""
valueTotal = 0
valueAverage = 0
for i in list:
    if capture:
        if i > capture:
            capture = i
    else:
        capture = i

    valueTotal += i

valueAverage = valueTotal / len(list)

print("\nMaximum value: " + str(capture))
print("Minimum value: " + str(min(list)))
print("Sum of all values: " + str(valueTotal))
print("Average value: " + str(valueAverage))