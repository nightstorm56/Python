# Task 3 - Gronky
# Creator - Val Jensen
# Unit 6 Assignment
# Course - CS-1400-LO1 XL

TITLE = ["One",
         "Two",
         "Three",
         "Four",
         "Five",
         "Six",
         "Seven",
         "Eight",
         "Nine",
         "Ten",
         "Baker",
         "Jester",
         "Page",
         "Scribe",
         "Squire",
         "Armorer",
         "Marshal"]

GANG = ["Jets",
        "Pollos",
        "Slugs",
        "Yokels",
        "Keiths",
        "Elbows"]

def convertCardToId(cardTitle, cardGang):
    return GANG.index(cardGang) * len(TITLE) + TITLE.index(cardTitle)