# Task 4 - Orbian Family
# Creator - Val Jensen
# Unit 6 Assignment
# Course - CS-1400-LO1 XL

from math import pi
from time import time

class Orbian:
    def __init__(self, name, headRad, bodyRad, bodyHeight):
        self.__name = name
        self.__headRad = headRad
        self.__headHeight = self.__headRad * 2
        self.__headVolume = (4 // 3) * pi * self.__headRad
        self.__bodyRad = bodyRad
        self.__bodyHeight = bodyHeight
        self.__bodyVolume = pi * ((self.__bodyRad ** 2) * self.__bodyHeight)
        self.__totalVolume = self.__headVolume + self.__bodyVolume
        self.__totalHeight = self.__headHeight + self.__bodyHeight
        self.__age = time()
        self.__embiggened = False

    def getName(self):
        return self.__name

    def setName(self, name):
        self.__name = name

    def getAge(self):
        return time() - self.__age

    def getHead(self):
        return self.__headRad

    def getBodyHeight(self):
        return self.__bodyHeight

    def getBodyRad(self):
        return self.__bodyRad

    def setVolume(self):
        self.__headVolume = (4 // 3) * pi * self.__headRad
        self.__bodyVolume = pi * ((self.__bodyRad ** 2) * self.__bodyHeight)
        self.__totalVolume = self.__headVolume + self.__bodyVolume

    def getVolume(self):
        return self.__totalVolume

    def getEmbiggened(self):
        return self.__embiggened

    def embiggenOrbian(self):
        if not self.__embiggened:
            self.__headRad += self.__headRad
            self.__bodyRad += self.__bodyRad
            self.__bodyHeight += (self.__bodyHeight * 3)
            Orbian.setVolume(self)
            self.__headHeight = self.__headRad * 2
            self.__totalHeight = self.__headHeight + self.__bodyHeight
            self.__embiggened = True

    def __gt__(self, other):
        return self.__totalVolume > other.__totalVolume

    def __lt__(self, other):
        return self.__totalVolume < other.__totalVolume

    def __eq__(self, other):
        return self.__totalVolume == other.__totalVolume

    def __len__(self):
        return self.__totalHeight

    def __add__(self, other):
        self.__headRad = int((int(self.__headRad) + int(other.__headRad)) * .25)
        self.__bodyRad = int((int(self.__bodyRad) + int(other.__bodyRad)) * .25)
        self.__bodyHeight = int((int(self.__bodyHeight) + int(other.__bodyHeight)) * .125)
        name = ""
        return Orbian(name, self.__headRad, self.__bodyRad, self.__bodyHeight)