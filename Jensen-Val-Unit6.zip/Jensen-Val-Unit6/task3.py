# Task 3 - Gronky
# Creator - Val Jensen
# Unit 6 Assignment
# Course - CS-1400-LO1 XL

from modules.deck import Deck
from time import sleep
from modules.gronkyutil import convertCardToId
from modules.gronkyutil import TITLE, GANG

def main():
    print("Welcome to Gronky Cards\n")
    print("Shuffling Cards", end="")
    thinking()

    deck = Deck()
    playerHand = []

    cardCount = int(input("How many cards would you like?: "))

    for i in range(cardCount):
        playerHand.append(deck.draw()) # Single line

    done = False
    while not done:
        print()
        print("Menu")
        print("\t(1) Display hand")
        print("\t(2) Sort by title")
        print("\t(3) Sort by gang")
        print("\t(4) Search for card")
        print("\t(5) Quit")
        choice = int(input("Choose an option: "))
        print()

        if choice == 1:
            displayHand(playerHand)
        elif choice == 2:
            selectSort(playerHand) # Single line
        elif choice == 3:
            insertSort(playerHand) # Single line
        elif choice == 4:
            cardSearch(playerHand) # Single line
        elif choice == 5:
            done = True # Not a function and not 'break'

def thinking():
    for i in range(5):
        print(".", end="")
        sleep(0.5)
    print()

def displayHand(hand):
    print("Your Hand")
    for i in hand:
        print("\t" + str(i)) # Not a single line. The entire function body

# Add other functions you need below
def selectSort(hand):
    for i in range(len(hand) - 1):
        currentMinIndex = i
        for j in range(i, len(hand)):
            x = hand[currentMinIndex].getID() % len(TITLE)
            y = hand[j].getID() % len(TITLE)
            if x > y:
                currentMinIndex = j

        if currentMinIndex != i:
            hand[i], hand[currentMinIndex] = hand[currentMinIndex], hand[i]

    print("Selection Sort by Title", end="")
    thinking()
    return hand


def insertSort(hand):
    for i in range(1, len(hand)):
        currentElement = hand[i]
        j = i - 1
        while j >= 0 and hand[j] > currentElement:
            hand[j + 1] = hand[j]
            j -= 1

        hand[j + 1] = currentElement

    print("Insert Sort by Gang", end="")
    thinking()

    return hand


def cardSearch(hand):
    print("Search for Card")
    for i in range(len(TITLE)):
        print("\t(" + str(TITLE.index(TITLE[i]) + 1) + ") " + str(TITLE[i]))
    userTitle = eval(input("Choose a Title: "))
    for i in range(len(GANG)):
        print("\t(" + str(GANG.index(GANG[i]) + 1) + ") " + str(GANG[i]))
    userGang = eval(input("Choose a Title: "))
    userID = (userGang - 1) * len(TITLE) + (userTitle - 1)
    insertSort(hand)
    print("Binary Search for " + str(TITLE[userTitle - 1]) + " of " + str(GANG[userGang - 1]), end="")
    thinking()
    found = binarySearch(hand, userID)
    print("\tCongrats! You have that card") if found >=0 else print("\tSorry. You do not have that card")

def binarySearch(hand, key):
    low = 0
    high = len(hand) - 1
    while high >= low:
        mid = (high + low) // 2
        if key == hand[mid].getID():
            return mid
        elif key < hand[mid].getID():
            high = mid - 1
        else:
            low = mid + 1

    return -1

main()