# Task 4 - Orbian Family
# Creator - Val Jensen
# Unit 6 Assignment
# Course - CS-1400-LO1 XL

from modules.orbian import Orbian
from time import sleep
from random import randint # Hint hint
from random import shuffle # Hint hint


def main():
    print("WELCOME TO ORBIAN FAMILY")
    print()

    family = []
    input("Hit Enter to Create the First Four Orbians")

    for i in range(0, 4):
        # Comment from Val - I had to fix str(i) to str(i+1) or the output would show Orbian 0 instead of 1
        name = input("\tEnter a name for Orbian " + str(i+1) + ": ")
        name = name.capitalize()
        family.append(Orbian(name, randint(2, 5), randint(3, 8), randint(5, 15))) # Fill in with an anonymous object

    print("\tCreating your Orbian Family", end="")
    thinking()

    done = False

    while not done:
        print()
        print("Menu")
        print("\t1) Meet Orbian Family")
        print("\t2) Compare Orbians")
        print("\t3) Orbian Info")
        print("\t4) Create Orbian Baby")
        print("\t5) Send Orbian to Pasture")
        print("\t6) Orbian Thanos")
        print("\t7) Quit")
        choice = int(input("Choose an option: "))
        print()

        if choice == 1:
            meetOrbians(family)
        elif choice == 2:
            compareOrbians(family)
        elif choice == 3:
            orbianInfo(family)
        elif choice == 4:
            bowChickaWowWow(family)
        elif choice == 5:
            pasturizePunIntended(family)
        elif choice == 6:
            ThanosSnap(family) # This function call should return something
        elif choice == 7:
            done = True # Do not use break

    print("Thanks for playing Orbian Family!!!")

def thinking():
    for i in range(5):
        print(".", end="")
        sleep(0.5)
    print()

def selectOrbian(family, selected=-1):
    for i in range(len(family)):
        print("\t" + str(i + 1) + ") " + family[i].getName(), end="")
        if i == selected:
            print(" (already selected)")
        else:
            print()

    return int(input("Select an Orbian: ")) - 1

# Add all required functions below
def meetOrbians(family):
    for i in range(len(family)):
        print("I am Orbian " + family[i].getName())

def compareOrbians(family):
    first, second = captureOrbians(family)
    print("\tPerforming Analysis", end="")
    thinking()
    print("\t", end="")
    if first.getVolume() > second.getVolume():
        print("Orbian " + first.getName() + " is larger than Orbian " + second.getName())
    elif first.getVolume() < second.getVolume():
        print("Orbian " + first.getName() + " is smaller than Orbian " + second.getName())
    elif first.getVolume() == second.getVolume():
        print("Orbian " + first.getName() + " is the same size as Orbian " + second.getName())

def orbianInfo(family):
    print("Select an Orbian to view")
    chosenOrbian = family[selectOrbian(family)]
    grewUp(chosenOrbian)
    print("Orbian " + chosenOrbian.getName() + " is " + str(int(chosenOrbian.getAge() / 5)) + " zungs old")
    print("\tand is " + str(int(chosenOrbian.getVolume())) + " zogs, and " + str(len(chosenOrbian)) + " zings")

def grewUp(orbian):
    if orbian.getAge() > 10 and not orbian.getEmbiggened():
        orbian.embiggenOrbian()

def bowChickaWowWow(family):
    first, second = captureOrbians(family, True)
    babyOrbian = first + second
    avgName = int((len(first.getName()) + len(second.getName())) / 2)
    name = ""
    tempName = []
    for i in first.getName():
        tempName += [i]
    for i in second.getName():
        tempName += [i]
    shuffle(tempName)
    for i in range(0, avgName):
        letterCapture = tempName.pop(randint(0, (avgName * 2) - (i + 1)))
        name += letterCapture.upper() if i == 0 else letterCapture.lower()
    babyOrbian.setName(name)
    family.append(babyOrbian)
    print("Creating an Orbian Baby", end="")
    thinking()
    print("Greetings Orbian " + babyOrbian.getName() + ", child of " + first.getName() + " and " + second.getName())

def captureOrbians(family, breeding=False):
    print("Select the first Orbian", end="")
    print(" parent") if breeding else print()
    numberOne = selectOrbian(family)
    firstSelected = family[numberOne]
    print("\nSelect the second Orbian", end="")
    print(" parent") if breeding else print()
    secondSelected = family[selectOrbian(family, numberOne)]
    grewUp(firstSelected)
    grewUp(secondSelected)
    return firstSelected, secondSelected

def pasturizePunIntended(family):
    print("Select an Orbian to send to pasture")
    orbian = selectOrbian(family)
    print("Farewell dear " + family[orbian].getName(), end="")
    family.pop(orbian)
    thinking()

def ThanosSnap(family):
    familySize = len(family)
    for i in range(0, int(familySize) // 2):
        shuffle(family)
        family.pop(randint(0, len(family) - 1))
    print("\tUh oh. Orbian Thanos just snapped his fingers", end="")
    thinking()
    return family

main()