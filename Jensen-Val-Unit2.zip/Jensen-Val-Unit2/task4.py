# Task 4 - Calculate and display an employee's gross (pre-tax) pay, withholds, and net pay.
# Creator - Val Jensen
# Unit 2 Assignment
# Course - CS-1400-LO1 XL

# User inputs
employee = input("Enter employee's name: ")
hours = int(input("Enter number of hours worked in a week: "))
payRate = float(input("Enter hourly pay rate: "))
fedRate = float(input("Enter federal tax withholding rate (ex. 0.12): "))
stateRate = float(input("Enter state tax withholding rate (ex. 0.06): "))

# Financial calculations
grossPay = hours * payRate
fedTake = fedRate * grossPay
stateTake = stateRate * grossPay
totalTake = fedTake + stateTake
netPay = grossPay - totalTake

# Build the message output
# New lines were put on their own lines for easier reading
msg = "\n"
msg += format((str.upper(employee) + "'S PAY INFORMATION"), "^40")
msg += "\n\n"
msg += format("Pay", "^40")
msg += "\n"
msg += format("Hours Worked:  " + str(format(hours, ">10")), ">40")
msg += "\n"
msg += format("Pay Rate: $" + format(payRate, ">10.2f"), ">40")
msg += "\n"
msg += format("Gross Pay: $" + format(grossPay, ">10.2f"), ">40")
msg += "\n\n"
msg += format("Deductions", "^40")
msg += "\n"
msg += format("Federal Withholding (" + str(format(fedRate, "0.1%")) + "): $"
              + str(format(fedTake, ">10.2f")), ">40")
msg += "\n"
msg += format("State Withholding (" + str(format(stateRate, "0.1%")) + "): $"
              + str(format(stateTake, ">10.2f")), ">40")
msg += "\n"
msg += format("Total Deduction: $" + str(format(totalTake, ">10.2f")), ">40")
msg += "\n\n"
msg += format("Net Pay: $" + str(format(netPay, ">10.2f")), ">40")

# Output the built message
print(msg)