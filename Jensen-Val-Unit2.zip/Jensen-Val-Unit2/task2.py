# Task 2 - Write a program that draws a target, such as one that would be used in archery based on user input.
# Creator - Val Jensen
# Unit 2 Assignment
# Course - CS-1400-LO1 XL

# importing the turtle module
import turtle

# Collecting the data from the user
xPos = int(input("Enter the left/right number of the target's center: "))
yPos = int(input("Enter the up/down number of the target's center: "))
diameter = int(input("Enter the diameter of your bullseye: "))

# Test variable - This is used as part of a test to ensure my target was centered on the user's
# originally intended location. Remove the comment of line 16 in conjunction with lines 66-68 to test
# oYPos = yPos

# Black Target (Largest Circle)
turtle.penup()
radius = (diameter/2)
yPos -= (radius * 4)
turtle.goto(xPos, yPos)
turtle.pendown()
turtle.color("black")
turtle.begin_fill()
radius *= 4
turtle.circle(radius)
turtle.end_fill()
turtle.penup()

# Light Blue Target (Second Largest Circle)
yPos += diameter / 2
turtle.goto(xPos, yPos)
turtle.pendown()
turtle.color("light blue")
turtle.begin_fill()
radius -= (diameter / 2)
turtle.circle(radius)
turtle.end_fill()
turtle.penup()

# Red Target (Second Smallest Circle)
yPos += diameter / 2
turtle.goto(xPos, yPos)
turtle.pendown()
turtle.color("red")
turtle.begin_fill()
radius -= (diameter / 2)
turtle.circle(radius)
turtle.end_fill()
turtle.penup()

# Yellow Target (Bullseye)
yPos += diameter / 2
turtle.goto(xPos, yPos)
turtle.pendown()
turtle.color("yellow")
turtle.begin_fill()
radius -= (diameter / 2)
turtle.circle(radius)
turtle.end_fill()

# Test Code - Remove comment on lines 16 & 66-68 to see the turtle draw a line to the center of the target
# This was made to ensure I had my calculations correct. If the line is skewed or doesn't end in the center,
# it would mean my calculations were off. Remove the comment of line 16 in conjunction with lines 66-68 to test
# turtle.color("black")
# yPos = oYPos
# turtle.goto(xPos, yPos)

# End and re-center
turtle.penup()
turtle.hideturtle()
turtle.goto(0, 0)
turtle.done()