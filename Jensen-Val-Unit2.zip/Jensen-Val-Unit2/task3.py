# Task 3 - Calculate the area of a regular polygon.
# Creator - Val Jensen
# Unit 2 Assignment
# Course - CS-1400-LO1 XL

# import the math module
import math

# Input the number of sides of the polygon
numSides = int(input("Please enter the amount of sides of your polygon: "))

# Input the length of one side of the polygon
lenSides = int(input("Please enter the length of one side of your polygon: "))

# Calculate the area of the polygon based on the user's input
area = (numSides * (math.pow(lenSides, 2))) / (4 * math.tan(math.pi / numSides))

# Round the area to five decimal places, convert the area to a string and display the value of the area
print("The area of your polygon is: " + str(round(area, 5)))