# Task 1 - Write a program that will calculate the future value of an investment with additional monthly payments.
# Creator - Val Jensen
# Unit 2 Assignment
# Course - CS-1400-LO1 XL

# Input how much the user is initially investing
investmentAmount = int(input("Enter an initial investment Amount: "))

# Input how much the interest rate is (normally seen as APR), and calculate it out to the monthly interest rate
monthlyInterestRate = float(input("Enter your Annual Percentage Rate (APR): ")) / 1200

# Input how many years the user is intending to invest and earn interest, which is then multiplied in to months
numberOfMonths = int(input("Enter how many years: ")) * 12

# Input how much money the user intends to put in of their own money every month
paymentAmount = int(input("Enter a monthly payment amount: "))

# This line calculates all of the given data together to see how much they will have after the time given
futureValue = investmentAmount * (1 + monthlyInterestRate) ** numberOfMonths + paymentAmount * (
            (1 + monthlyInterestRate) ** numberOfMonths - 1) / monthlyInterestRate * (1 + monthlyInterestRate)

# This is the output of the data for the user to see
print("Your future value is: $" + format(futureValue, "0.2f"))